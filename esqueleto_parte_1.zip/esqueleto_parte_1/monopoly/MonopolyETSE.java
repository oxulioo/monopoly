package monopoly;

public class MonopolyETSE {

    public static void main(String[] args) {
        new Menu();
    }
    
}
